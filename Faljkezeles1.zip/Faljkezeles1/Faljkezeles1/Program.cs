﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Faljkezeles
{
    struct Jatekok
    {
        public string Nev;
        public int Ar;
    }
    class Program
    {
        static List<Jatekok> Games;
        static void Main(string[] args)
        {
            F01();
            F02();
            F03();
            F04();


            Console.ReadKey();
        }

        private static void F04()
        {
            Console.WriteLine("");
            Console.WriteLine("Van-e raktáron Mortal Kombat 11?");
            int i = 0;
            Console.ReadLine();
            while (i < Games.Count && Games[i].Nev != "Mortal Kombat 11")
            {
                i++;
            }
            if (i < Games.Count)
            {
                Console.WriteLine("van");
            }
            else
            {
                Console.WriteLine("nincs");

            }
        }

            private static void F03()
        {
            Console.WriteLine("");
            int sum = 0;

            foreach (var g in Games)
            {
                sum += (g.Ar);
            }
            Console.WriteLine($"-Játékök összege: {sum} Ft");
        }

        private static void F02()
        {
            Console.WriteLine($"-A Játékok darab száma: {Games.Count} db");
        }

        private static void F01()
        {
            Games = new List<Jatekok>();
            var sr = new StreamReader(@"..\..\Res\game.txt", Encoding.UTF8);
            while (!sr.EndOfStream)
            {
                var t = sr.ReadLine().Split(';');

                Games.Add(new Jatekok()
                {
                    Nev = t[0],
                    Ar = int.Parse(t[1]),
                });
            }
            sr.Close();
        }
    }
}
